let canvas = document.querySelector('canvas');
let webgl = canvas.getContext('webgl');
let vertices = [
    0.5, 0.5, -0.5,
    0.5, -0.5, -0.5,
    -0.5, -0.5, -0.5,
    -0.5, 0.5,  -0.5,

    //back box
    0.5, 0.5, 0.5,
    0.5, -0.5,  0.5,
    -0.5, -0.5, 0.5,
    -0.5, 0.5,  0.5
];

let tVertices = [
    1.0, 1.0,
    1.0, 0.0,
    0.0, 0.0,
    0.0, 1.0,
    1.0, 1.0,
    1.0, 0.0,
    0.0, 0.0,
    0.0, 1.0,
];

let proto = new WebGLAssist(webgl, canvas);
let tBuffer = proto.createBuffer(tVertices);
let texture = proto.TextureInit(document.querySelector('img'));
let buffer = proto.createBuffer(vertices);
console.log(buffer);


let vsShader = `
precision mediump float;
attribute vec3 vecposition;
attribute vec2 vTexture;
varying vec2 fTexture;
uniform mat4 zmat;
void main()
{
    fTexture = vTexture;
    gl_Position = zmat*vec4(vecposition,1.0);
}
`;

let fsShader = `
    precision mediump float;
    uniform vec3 color;
    varying vec2 fTexture;
    uniform sampler2D fsampler;
    void main(){
        gl_FragColor = texture2D(fsampler,fTexture);
    }

`;

let vShader = proto.compileShader(vsShader, webgl.VERTEX_SHADER);
let fShader = proto.compileShader(fsShader, webgl.FRAGMENT_SHADER);
let program = proto.createProgram(vShader, fShader);
console.log(program);
addPicevent();
let position = proto.PositionInit(program, "vecposition",3);
console.log(position);
let phi = 0;
webgl.bindBuffer(webgl.ARRAY_BUFFER, tBuffer);
let tPos = proto.PositionInit(program, 'vTexture',2);
let zmatloc = webgl.getUniformLocation(program, 'zmat');
let color = webgl.getUniformLocation(program, 'color');
function animate(){
    let mat4 = proto.rotateZ(proto.createIdentityMatrix(),phi);
    mat4 = proto.rotateY(mat4, phi);
    webgl.clear(webgl.COLOR_BUFFER_BIT);
    webgl.uniformMatrix4fv(zmatloc, false, mat4);
    phi += 0.01;
    webgl.uniform3f(color, 0.0, 0.0, 1.0);
    webgl.drawArrays(webgl.TRIANGLE_FAN, 0, 4);
    webgl.uniform3f(color, 1.0, 0.0, 1.0);
    webgl.drawArrays(webgl.TRIANGLE_FAN, 4, 4);
    // console.log("1");
    requestAnimationFrame(animate);
}
animate();

function addPicevent()
{
    let picture = document.querySelectorAll('img');
    for(let i = 0; i < picture.length; i++)
        {
            console.log(picture[i],"Picture", i);
            picture[i].addEventListener('click', () => {
                webgl.texImage2D(webgl.TEXTURE_2D, 0, webgl.RGBA, webgl.RGBA, webgl.UNSIGNED_BYTE, picture[i]); 
            })
        }
}