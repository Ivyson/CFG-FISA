# Exam-Prep

## Overview Of the project
Welcome to Exam-Prep, a streamlined mini-library designed to simplify 3D rendering tasks using WebGL. This toolkit leverages object-oriented programming principles to enhance code simplicity and readability, providing a robust foundation for creating various shapes and handling WebGL operations efficiently. Initially, this project was mwant for exam preparation and practising a better approach to use when writing my exam for Computer Graphics.

## Features 
   - Based on the experience i have dealing with WebGL, I have designed a mini-Library Like project which offers a set of reusability, high-level functions         encapsulated within a single class.
   -  Drawing from my background in Java, I've implemented an object-oriented approach in JavaScript to ensure code modularity, maintainability, and ease of         understanding.
   -  The library encapsulates essential WebGL functionalities such as buffer management, shader compilation, program linking, and texture initialization.           All these functions are neatly organized within a single class for convenience.
## Key Features
1. Automatically handles the creation of a canvas and initialization of the WebGL context, including support for experimental WebGL.
2. Simplifies the creation and binding of buffers, ensuring efficient data handling for vertex attributes.
3. Provides methods to compile vertex and fragment shaders and link them into a program, with error handling to facilitate debugging.
4. Includes utility functions for common matrix operations such as perspective projection, and rotations (around the X, Y, and Z axes), leveraging linear algebra for 3D transformations.
5. Facilitates texture creation, parameter setting, and mipmap generation, ensuring compatibility with both power-of-two and non-power-of-two textures.
## Features to be implemented
1. Texturing, preferably have a button that selects which picture is showing on the square
2. Allow Movement using buttons - Use Event Listeners
3. Experiment on Perspective view
4. Apply Rotations using buttons
